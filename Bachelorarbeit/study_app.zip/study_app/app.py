"""
NL vs Adjacency Matrix reading study.

A small self-contained Flask app: researchers upload paired node-link (NL) and
adjacency-matrix (AM) images of the same network plus a battery of reading
tasks, participants work through a randomised quiz, and every answer/timing/
confidence rating is logged to SQLite for later analysis. Implements the
framework in nl_vs_matrix_study_design.md.
"""

import csv
import io
import json
import os
import random
import sqlite3
import time
import uuid
from functools import wraps

from flask import (
    Flask, abort, flash, g, redirect, render_template, request,
    send_from_directory, session, url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INSTANCE_DIR = os.path.join(BASE_DIR, "instance")
DB_PATH = os.path.join(INSTANCE_DIR, "study.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")
ALLOWED_EXT = {"png", "jpg", "jpeg", "gif", "webp"}

TASK_CATEGORIES = [
    ("adjacency", "Adjacency (most connections)"),
    ("common_connections", "Common connections"),
    ("connectivity_path", "Connectivity / shortest path"),
    ("neighbourhood", "Neighbourhood / cluster identification"),
    ("bridge", "Bridge identification"),
    ("outlier", "Outlier / isolate detection"),
    ("link_confidence", "On links (highest confidence)"),
    ("node_attribute", "On nodes (attribute-based)"),
    ("overview_density", "Overview / density estimation"),
    ("path_following", "Follow-path / revisit (node-link only)"),
]
INPUT_TYPES = ["text", "number", "node_id", "node_list", "mcq"]
ORDERING_METHODS = ["alphabetical", "hc_olo", "spectral", "ground_truth", "other"]

os.makedirs(INSTANCE_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-me")
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024  # 25 MB per upload
ADMIN_PASSWORD_HASH = generate_password_hash(os.environ.get("ADMIN_PASSWORD", "changeme"))


# --------------------------------------------------------------------------
# DB helpers
# --------------------------------------------------------------------------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        conn.executescript(f.read())
    conn.close()


init_db()


# --------------------------------------------------------------------------
# Small utilities
# --------------------------------------------------------------------------

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("admin_login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def parse_set(text):
    if not text:
        return set()
    parts = [p.strip().lower() for p in text.replace(";", ",").split(",")]
    return {p for p in parts if p}


def score_answer(task, answer):
    """Return a 0..1 score, or None if the task can't be auto-scored."""
    gt = (task["ground_truth"] or "").strip()
    if not gt or task["input_type"] == "text":
        return None
    answer = (answer or "").strip()
    if task["input_type"] in ("mcq", "node_id"):
        return 1.0 if answer.strip().lower() == gt.lower() else 0.0
    if task["input_type"] == "number":
        try:
            return 1.0 if float(answer) == float(gt) else 0.0
        except (TypeError, ValueError):
            return 0.0
    if task["input_type"] == "node_list":
        given, truth = parse_set(answer), parse_set(gt)
        if not truth:
            return None
        if not given and not truth:
            return 1.0
        inter = given & truth
        union = given | truth
        return len(inter) / len(union) if union else None
    return None


# --------------------------------------------------------------------------
# Public: landing + quiz
# --------------------------------------------------------------------------

@app.route("/")
def index():
    db = get_db()
    datasets = db.execute("SELECT * FROM datasets ORDER BY name").fetchall()
    comparison_ready = any(
        db.execute(
            "SELECT COUNT(*) c FROM images WHERE dataset_id=? AND representation='NL'", (d["id"],)
        ).fetchone()["c"] > 0
        and db.execute(
            "SELECT COUNT(*) c FROM images WHERE dataset_id=? AND representation='AM'", (d["id"],)
        ).fetchone()["c"] > 0
        for d in datasets
    )
    ordering_ready = any(
        db.execute(
            "SELECT COUNT(*) c FROM images WHERE dataset_id=? AND representation='AM'", (d["id"],)
        ).fetchone()["c"] >= 2
        for d in datasets
    )
    return render_template(
        "index.html", datasets=datasets,
        comparison_ready=comparison_ready, ordering_ready=ordering_ready,
    )


def _default_am_image(db, dataset_id):
    row = db.execute(
        "SELECT * FROM images WHERE dataset_id=? AND representation='AM' AND is_default=1", (dataset_id,)
    ).fetchone()
    if row:
        return row
    return db.execute(
        "SELECT * FROM images WHERE dataset_id=? AND representation='AM' ORDER BY id LIMIT 1", (dataset_id,)
    ).fetchone()


def build_comparison_plan(db):
    steps = []
    datasets = db.execute("SELECT * FROM datasets ORDER BY name").fetchall()
    eligible = []
    for d in datasets:
        nl = db.execute(
            "SELECT * FROM images WHERE dataset_id=? AND representation='NL' ORDER BY id LIMIT 1", (d["id"],)
        ).fetchone()
        am = _default_am_image(db, d["id"])
        if nl and am:
            eligible.append((d, nl, am))
    random.shuffle(eligible)
    for d, nl, am in eligible:
        reps = [("NL", nl), ("AM", am)]
        random.shuffle(reps)
        for rep, image in reps:
            tasks = db.execute(
                """SELECT * FROM tasks WHERE dataset_id=? AND ordering_only=0
                   AND (representation_scope='both' OR representation_scope=?)
                   ORDER BY sort_order, id""",
                (d["id"], rep),
            ).fetchall()
            for t in tasks:
                steps.append({
                    "type": "task", "dataset_id": d["id"], "representation": rep,
                    "ordering_method": image["ordering_method"], "image_id": image["id"],
                    "task_id": t["id"],
                })
            steps.append({
                "type": "rating", "dataset_id": d["id"], "representation": rep,
                "ordering_method": image["ordering_method"],
            })
        steps.append({"type": "preference", "dataset_id": d["id"]})
    return steps


def build_ordering_plan(db):
    steps = []
    datasets = db.execute("SELECT * FROM datasets ORDER BY name").fetchall()
    eligible = []
    for d in datasets:
        variants = db.execute(
            "SELECT * FROM images WHERE dataset_id=? AND representation='AM' ORDER BY id", (d["id"],)
        ).fetchall()
        if len(variants) >= 2:
            eligible.append((d, list(variants)))
    random.shuffle(eligible)
    for d, variants in eligible:
        random.shuffle(variants)
        tasks = db.execute(
            """SELECT * FROM tasks WHERE dataset_id=? AND category IN ('neighbourhood','bridge')
               ORDER BY sort_order, id""",
            (d["id"],),
        ).fetchall()
        if not tasks:
            continue
        for image in variants:
            for t in tasks:
                steps.append({
                    "type": "task", "dataset_id": d["id"], "representation": "AM",
                    "ordering_method": image["ordering_method"], "image_id": image["id"],
                    "task_id": t["id"],
                })
            steps.append({
                "type": "rating", "dataset_id": d["id"], "representation": "AM",
                "ordering_method": image["ordering_method"],
            })
    return steps


@app.route("/quiz/start", methods=["POST"])
def quiz_start():
    mode = request.form.get("mode")
    if mode not in ("comparison", "ordering"):
        abort(400)
    db = get_db()
    steps = build_comparison_plan(db) if mode == "comparison" else build_ordering_plan(db)
    if not steps:
        flash("No datasets are ready for that mode yet.")
        return redirect(url_for("index"))
    sid = str(uuid.uuid4())
    db.execute(
        "INSERT INTO sessions (id, mode, user_agent) VALUES (?,?,?)",
        (sid, mode, request.headers.get("User-Agent", "")[:255]),
    )
    db.execute(
        "INSERT INTO quiz_state (session_id, plan_json, pos) VALUES (?,?,0)",
        (sid, json.dumps(steps)),
    )
    db.commit()
    session["quiz_session_id"] = sid
    return redirect(url_for("quiz_step"))


def _current_state():
    sid = session.get("quiz_session_id")
    if not sid:
        return None, None
    db = get_db()
    row = db.execute("SELECT * FROM quiz_state WHERE session_id=?", (sid,)).fetchone()
    if not row:
        return None, None
    return sid, row


@app.route("/quiz/step")
def quiz_step():
    sid, state = _current_state()
    if not state:
        return redirect(url_for("index"))
    plan = json.loads(state["plan_json"])
    pos = state["pos"]
    if pos >= len(plan):
        db = get_db()
        db.execute("UPDATE sessions SET completed_at=datetime('now') WHERE id=?", (sid,))
        db.commit()
        return redirect(url_for("quiz_done"))

    step = plan[pos]
    db = get_db()
    total = len(plan)
    dataset = db.execute("SELECT * FROM datasets WHERE id=?", (step["dataset_id"],)).fetchone()

    if step["type"] == "task":
        task = db.execute("SELECT * FROM tasks WHERE id=?", (step["task_id"],)).fetchone()
        image = db.execute("SELECT * FROM images WHERE id=?", (step["image_id"],)).fetchone()
        options = json.loads(task["options"]) if task["options"] else []
        session["shown_at"] = time.time()
        return render_template(
            "quiz_task.html", step_no=pos + 1, total=total, dataset=dataset,
            task=task, image=image, options=options, representation=step["representation"],
        )
    if step["type"] == "rating":
        return render_template(
            "quiz_rating.html", step_no=pos + 1, total=total, dataset=dataset,
            representation=step["representation"],
        )
    if step["type"] == "preference":
        nl = db.execute(
            "SELECT * FROM images WHERE dataset_id=? AND representation='NL' LIMIT 1", (dataset["id"],)
        ).fetchone()
        am = _default_am_image(db, dataset["id"])
        return render_template(
            "quiz_preference.html", step_no=pos + 1, total=total, dataset=dataset, nl=nl, am=am,
        )
    abort(500)


@app.route("/quiz/answer", methods=["POST"])
def quiz_answer():
    sid, state = _current_state()
    if not state:
        return redirect(url_for("index"))
    plan = json.loads(state["plan_json"])
    pos = state["pos"]
    if pos >= len(plan):
        return redirect(url_for("quiz_done"))
    step = plan[pos]
    db = get_db()

    if step["type"] == "task":
        task = db.execute("SELECT * FROM tasks WHERE id=?", (step["task_id"],)).fetchone()
        answer = request.form.get("answer", "").strip()
        confidence = request.form.get("confidence", type=int)
        shown_at = session.pop("shown_at", None)
        response_ms = int((time.time() - shown_at) * 1000) if shown_at else None
        score = score_answer(task, answer)
        db.execute(
            """INSERT INTO responses
               (session_id, dataset_id, task_id, image_id, representation, ordering_method,
                answer, score, response_ms, confidence)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (sid, step["dataset_id"], task["id"], step["image_id"], step["representation"],
             step["ordering_method"], answer, score, response_ms, confidence),
        )
    elif step["type"] == "rating":
        workload = request.form.get("workload", type=int)
        db.execute(
            """INSERT INTO block_ratings (session_id, dataset_id, representation, ordering_method, workload)
               VALUES (?,?,?,?,?)""",
            (sid, step["dataset_id"], step["representation"], step["ordering_method"], workload),
        )
    elif step["type"] == "preference":
        preferred = request.form.get("preferred")
        if preferred not in ("NL", "AM"):
            abort(400)
        db.execute(
            "INSERT INTO preferences (session_id, dataset_id, preferred) VALUES (?,?,?)",
            (sid, step["dataset_id"], preferred),
        )

    db.execute("UPDATE quiz_state SET pos=pos+1 WHERE session_id=?", (sid,))
    db.commit()
    return redirect(url_for("quiz_step"))


@app.route("/quiz/done")
def quiz_done():
    return render_template("quiz_done.html")


@app.route("/uploads/<int:dataset_id>/<path:filename>")
def uploaded_file(dataset_id, filename):
    return send_from_directory(os.path.join(UPLOAD_DIR, str(dataset_id)), filename)


# --------------------------------------------------------------------------
# Admin
# --------------------------------------------------------------------------

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        pw = request.form.get("password", "")
        if check_password_hash(ADMIN_PASSWORD_HASH, pw):
            session["admin"] = True
            return redirect(request.args.get("next") or url_for("admin_dashboard"))
        flash("Wrong password.")
    return render_template("admin_login.html")


@app.route("/admin/logout")
def admin_logout():
    session.pop("admin", None)
    return redirect(url_for("index"))


@app.route("/admin")
@login_required
def admin_dashboard():
    db = get_db()
    datasets = db.execute(
        """SELECT d.*,
                  (SELECT COUNT(*) FROM images i WHERE i.dataset_id=d.id AND i.representation='NL') nl_count,
                  (SELECT COUNT(*) FROM images i WHERE i.dataset_id=d.id AND i.representation='AM') am_count,
                  (SELECT COUNT(*) FROM tasks t WHERE t.dataset_id=d.id) task_count
           FROM datasets d ORDER BY d.created_at DESC"""
    ).fetchall()
    session_count = db.execute("SELECT COUNT(*) c FROM sessions WHERE completed_at IS NOT NULL").fetchone()["c"]
    return render_template("admin_dashboard.html", datasets=datasets, session_count=session_count)


@app.route("/admin/datasets/new", methods=["GET", "POST"])
@login_required
def admin_dataset_new():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        description = request.form.get("description", "").strip()
        if not name:
            flash("Name is required.")
            return render_template("admin_dataset_new.html")
        db = get_db()
        cur = db.execute("INSERT INTO datasets (name, description) VALUES (?,?)", (name, description))
        db.commit()
        return redirect(url_for("admin_dataset", dataset_id=cur.lastrowid))
    return render_template("admin_dataset_new.html")


@app.route("/admin/datasets/<int:dataset_id>")
@login_required
def admin_dataset(dataset_id):
    db = get_db()
    dataset = db.execute("SELECT * FROM datasets WHERE id=?", (dataset_id,)).fetchone()
    if not dataset:
        abort(404)
    images = db.execute("SELECT * FROM images WHERE dataset_id=? ORDER BY representation, id", (dataset_id,)).fetchall()
    tasks = db.execute("SELECT * FROM tasks WHERE dataset_id=? ORDER BY sort_order, id", (dataset_id,)).fetchall()
    return render_template(
        "admin_dataset.html", dataset=dataset, images=images, tasks=tasks,
        categories=TASK_CATEGORIES, input_types=INPUT_TYPES, ordering_methods=ORDERING_METHODS,
    )


@app.route("/admin/datasets/<int:dataset_id>/delete", methods=["POST"])
@login_required
def admin_dataset_delete(dataset_id):
    db = get_db()
    db.execute("DELETE FROM datasets WHERE id=?", (dataset_id,))
    db.commit()
    flash("Dataset deleted.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/datasets/<int:dataset_id>/images", methods=["POST"])
@login_required
def admin_upload_image(dataset_id):
    db = get_db()
    dataset = db.execute("SELECT * FROM datasets WHERE id=?", (dataset_id,)).fetchone()
    if not dataset:
        abort(404)
    file = request.files.get("file")
    representation = request.form.get("representation")
    ordering_method = request.form.get("ordering_method") or None
    if representation not in ("NL", "AM"):
        flash("Pick a representation type.")
        return redirect(url_for("admin_dataset", dataset_id=dataset_id))
    if not file or file.filename == "" or not allowed_file(file.filename):
        flash("Choose a valid image file (png/jpg/jpeg/gif/webp).")
        return redirect(url_for("admin_dataset", dataset_id=dataset_id))

    folder = os.path.join(UPLOAD_DIR, str(dataset_id))
    os.makedirs(folder, exist_ok=True)
    ext = file.filename.rsplit(".", 1)[1].lower()
    stored_name = f"{uuid.uuid4().hex}.{ext}"
    file.save(os.path.join(folder, secure_filename(stored_name)))

    is_default = 1 if representation == "AM" and request.form.get("is_default") == "on" else 0
    if is_default:
        db.execute("UPDATE images SET is_default=0 WHERE dataset_id=? AND representation='AM'", (dataset_id,))
    db.execute(
        """INSERT INTO images (dataset_id, representation, ordering_method, filename, is_default)
           VALUES (?,?,?,?,?)""",
        (dataset_id, representation, ordering_method if representation == "AM" else None, stored_name, is_default),
    )
    db.commit()
    flash("Image uploaded.")
    return redirect(url_for("admin_dataset", dataset_id=dataset_id))


@app.route("/admin/images/<int:image_id>/delete", methods=["POST"])
@login_required
def admin_delete_image(image_id):
    db = get_db()
    image = db.execute("SELECT * FROM images WHERE id=?", (image_id,)).fetchone()
    if image:
        path = os.path.join(UPLOAD_DIR, str(image["dataset_id"]), image["filename"])
        if os.path.exists(path):
            os.remove(path)
        db.execute("DELETE FROM images WHERE id=?", (image_id,))
        db.commit()
        return redirect(url_for("admin_dataset", dataset_id=image["dataset_id"]))
    abort(404)


@app.route("/admin/images/<int:image_id>/set_default", methods=["POST"])
@login_required
def admin_set_default_image(image_id):
    db = get_db()
    image = db.execute("SELECT * FROM images WHERE id=?", (image_id,)).fetchone()
    if not image:
        abort(404)
    db.execute("UPDATE images SET is_default=0 WHERE dataset_id=? AND representation='AM'", (image["dataset_id"],))
    db.execute("UPDATE images SET is_default=1 WHERE id=?", (image_id,))
    db.commit()
    return redirect(url_for("admin_dataset", dataset_id=image["dataset_id"]))


@app.route("/admin/datasets/<int:dataset_id>/tasks", methods=["POST"])
@login_required
def admin_add_task(dataset_id):
    db = get_db()
    prompt = request.form.get("prompt", "").strip()
    category = request.form.get("category")
    input_type = request.form.get("input_type")
    representation_scope = request.form.get("representation_scope", "both")
    ground_truth = request.form.get("ground_truth", "").strip() or None
    ordering_only = 1 if request.form.get("ordering_only") == "on" else 0
    options_raw = request.form.get("options", "").strip()
    options = json.dumps([o.strip() for o in options_raw.split(",") if o.strip()]) if options_raw else None
    if not prompt or input_type not in INPUT_TYPES:
        flash("A prompt and a valid input type are required.")
        return redirect(url_for("admin_dataset", dataset_id=dataset_id))
    max_order = db.execute("SELECT COALESCE(MAX(sort_order),0) m FROM tasks WHERE dataset_id=?", (dataset_id,)).fetchone()["m"]
    db.execute(
        """INSERT INTO tasks (dataset_id, category, prompt, input_type, options, ground_truth,
                               representation_scope, ordering_only, sort_order)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (dataset_id, category, prompt, input_type, options, ground_truth,
         representation_scope, ordering_only, max_order + 1),
    )
    db.commit()
    flash("Task added.")
    return redirect(url_for("admin_dataset", dataset_id=dataset_id))


@app.route("/admin/tasks/<int:task_id>/delete", methods=["POST"])
@login_required
def admin_delete_task(task_id):
    db = get_db()
    task = db.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
    if task:
        db.execute("DELETE FROM tasks WHERE id=?", (task_id,))
        db.commit()
        return redirect(url_for("admin_dataset", dataset_id=task["dataset_id"]))
    abort(404)


@app.route("/admin/results")
@login_required
def admin_results():
    db = get_db()
    by_rep = db.execute(
        """SELECT d.name dataset, r.representation, r.ordering_method,
                  COUNT(*) n, AVG(r.score) avg_score, AVG(r.response_ms) avg_ms, AVG(r.confidence) avg_conf
           FROM responses r JOIN datasets d ON d.id=r.dataset_id
           GROUP BY r.dataset_id, r.representation, r.ordering_method
           ORDER BY d.name, r.representation"""
    ).fetchall()
    by_category = db.execute(
        """SELECT t.category, r.representation, COUNT(*) n, AVG(r.score) avg_score,
                  AVG(r.response_ms) avg_ms, AVG(r.confidence) avg_conf
           FROM responses r JOIN tasks t ON t.id=r.task_id
           GROUP BY t.category, r.representation
           ORDER BY t.category, r.representation"""
    ).fetchall()
    prefs = db.execute(
        """SELECT d.name dataset, p.preferred, COUNT(*) n
           FROM preferences p JOIN datasets d ON d.id=p.dataset_id
           GROUP BY p.dataset_id, p.preferred ORDER BY d.name"""
    ).fetchall()
    workload = db.execute(
        """SELECT d.name dataset, b.representation, b.ordering_method, AVG(b.workload) avg_workload, COUNT(*) n
           FROM block_ratings b JOIN datasets d ON d.id=b.dataset_id
           GROUP BY b.dataset_id, b.representation, b.ordering_method
           ORDER BY d.name, b.representation"""
    ).fetchall()
    return render_template(
        "admin_results.html", by_rep=by_rep, by_category=by_category, prefs=prefs, workload=workload,
    )


def _csv_response(rows, headers, filename):
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(headers)
    for row in rows:
        writer.writerow([row[h] for h in headers])
    output = buf.getvalue()
    return app.response_class(
        output, mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@app.route("/admin/export/responses.csv")
@login_required
def export_responses():
    db = get_db()
    rows = db.execute(
        """SELECT r.session_id, d.name dataset, r.representation, r.ordering_method, t.category,
                  t.prompt, r.answer, r.score, r.response_ms, r.confidence, r.created_at
           FROM responses r
           JOIN datasets d ON d.id=r.dataset_id
           JOIN tasks t ON t.id=r.task_id
           ORDER BY r.created_at"""
    ).fetchall()
    headers = ["session_id", "dataset", "representation", "ordering_method", "category",
               "prompt", "answer", "score", "response_ms", "confidence", "created_at"]
    return _csv_response(rows, headers, "responses.csv")


@app.route("/admin/export/ratings.csv")
@login_required
def export_ratings():
    db = get_db()
    rows = db.execute(
        """SELECT b.session_id, d.name dataset, b.representation, b.ordering_method, b.workload, b.created_at
           FROM block_ratings b JOIN datasets d ON d.id=b.dataset_id ORDER BY b.created_at"""
    ).fetchall()
    headers = ["session_id", "dataset", "representation", "ordering_method", "workload", "created_at"]
    return _csv_response(rows, headers, "ratings.csv")


@app.route("/admin/export/preferences.csv")
@login_required
def export_preferences():
    db = get_db()
    rows = db.execute(
        """SELECT p.session_id, d.name dataset, p.preferred, p.created_at
           FROM preferences p JOIN datasets d ON d.id=p.dataset_id ORDER BY p.created_at"""
    ).fetchall()
    headers = ["session_id", "dataset", "preferred", "created_at"]
    return _csv_response(rows, headers, "preferences.csv")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
