-- NL vs Adjacency Matrix study: schema
-- See nl_vs_matrix_study_design.md at the repo root for the framework this implements.

CREATE TABLE IF NOT EXISTS datasets (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    description TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS images (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    dataset_id       INTEGER NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    representation   TEXT NOT NULL CHECK(representation IN ('NL','AM')),
    ordering_method  TEXT,               -- AM only: alphabetical / hc_olo / spectral / ground_truth ...
    filename         TEXT NOT NULL,
    is_default       INTEGER NOT NULL DEFAULT 0,  -- default AM variant used in the comparison mode
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tasks (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    dataset_id            INTEGER NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    category              TEXT NOT NULL,
    prompt                TEXT NOT NULL,
    input_type            TEXT NOT NULL CHECK(input_type IN ('text','number','node_id','node_list','mcq')),
    options               TEXT,           -- JSON array of strings, mcq only
    ground_truth          TEXT,           -- optional, enables auto-scoring
    representation_scope  TEXT NOT NULL DEFAULT 'both' CHECK(representation_scope IN ('both','NL','AM')),
    ordering_only         INTEGER NOT NULL DEFAULT 0,  -- 1 = RQ3 ordering-comparison task only
    sort_order            INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS sessions (
    id           TEXT PRIMARY KEY,
    mode         TEXT NOT NULL CHECK(mode IN ('comparison','ordering')),
    user_agent   TEXT,
    started_at   TEXT NOT NULL DEFAULT (datetime('now')),
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS responses (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id       TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    dataset_id       INTEGER NOT NULL,
    task_id          INTEGER NOT NULL,
    image_id         INTEGER NOT NULL,
    representation   TEXT NOT NULL,
    ordering_method  TEXT,
    answer           TEXT,
    score            REAL,    -- 0..1, NULL if unscored (no ground truth / free text)
    response_ms      INTEGER,
    confidence       INTEGER, -- 1-5
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS block_ratings (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id       TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    dataset_id       INTEGER NOT NULL,
    representation   TEXT NOT NULL,
    ordering_method  TEXT,
    workload         INTEGER NOT NULL, -- 1-7
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Server-side quiz progress, keyed by session id (kept out of the cookie since
-- a full study plan can exceed the ~4KB signed-cookie size limit).
CREATE TABLE IF NOT EXISTS quiz_state (
    session_id TEXT PRIMARY KEY REFERENCES sessions(id) ON DELETE CASCADE,
    plan_json  TEXT NOT NULL,
    pos        INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS preferences (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    dataset_id   INTEGER NOT NULL,
    preferred    TEXT NOT NULL CHECK(preferred IN ('NL','AM')),
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
