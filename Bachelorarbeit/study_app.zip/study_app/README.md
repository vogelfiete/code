# NL vs. Adjacency Matrix reading study

A small Flask + SQLite app implementing the comparison framework from
`nl_vs_matrix_study_design.md`: researchers upload paired node-link (NL) and
adjacency-matrix (AM) images of the same network plus a battery of reading
tasks (adjacency, common connections, connectivity, neighbourhood/cluster,
bridge, outlier, link-confidence, node-attribute, overview/density,
path-following), and participants work through a randomised quiz. Every
answer, response time, confidence rating, per-block workload rating, and
representation preference is logged to SQLite for export.

Two quiz modes:

- **Representation comparison** (RQ1/RQ2) — for each dataset, shows the NL
  and the default AM image in random order, running the shared task battery
  on each, then asks for a forced-choice preference.
- **Matrix ordering comparison** (RQ3) — for datasets with two or more AM
  images tagged with different `ordering_method`s, cycles through them in
  random order running only the neighbourhood/bridge tasks.

## Local development (any OS)

```bash
cd Bachelorarbeit/study_app
python -m venv .venv
.venv/Scripts/activate       # Windows; use `source .venv/bin/activate` on Linux/Mac
pip install -r requirements.txt
set ADMIN_PASSWORD=choose-a-password   # PowerShell: $env:ADMIN_PASSWORD="..."
python app.py
```

Visit `http://localhost:5000`. The SQLite DB is created automatically at
`instance/study.db` on first run; uploaded images land in `uploads/<dataset_id>/`.
Log in at `/admin/login` (password from `ADMIN_PASSWORD`, default `changeme`
if unset — **do not leave that as-is anywhere reachable from outside your
machine**) to create a dataset, upload NL/AM images, and add tasks.

## Hosting it on a Raspberry Pi

This assumes Raspberry Pi OS (Debian-based) with Python 3.9+ already on it,
and that you'll reach the Pi over SSH from another machine to set this up.

### 1. Get the code onto the Pi

Copy just the `study_app/` folder over (the rest of the Bachelorarbeit repo
isn't needed to run the study), e.g.:

```bash
rsync -av --exclude instance --exclude uploads study_app/ pi@<pi-host>:/home/pi/nlvsmatrix/
```

or `git clone` the repo on the Pi and `cd` into `Bachelorarbeit/study_app`.

### 2. Install and configure

```bash
cd /home/pi/nlvsmatrix
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-prod.txt   # Flask + gunicorn
```

Create an env file the service will read (keep this out of git):

```bash
cat > /home/pi/nlvsmatrix/.env <<'EOF'
ADMIN_PASSWORD=set-a-real-password-here
SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
EOF
```

(Run that `python3 -c ...` once yourself and paste the actual hex string in —
env files don't expand shell commands.)

### 3. Run it as a systemd service (survives reboots/crashes)

`/etc/systemd/system/nlvsmatrix.service`:

```ini
[Unit]
Description=NL vs Matrix study
After=network.target

[Service]
User=pi
WorkingDirectory=/home/pi/nlvsmatrix
EnvironmentFile=/home/pi/nlvsmatrix/.env
ExecStart=/home/pi/nlvsmatrix/.venv/bin/gunicorn -w 2 -b 127.0.0.1:8000 app:app
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now nlvsmatrix
sudo systemctl status nlvsmatrix     # confirm it's running
```

It's now listening on `127.0.0.1:8000` — reachable only from the Pi itself.
The next step puts a real web server in front of it for HTTPS and to make it
reachable from your LAN/internet.

### 4. Put a reverse proxy in front of it (HTTPS)

**Caddy** is the least fiddly option — it gets you free automatic HTTPS with
a 4-line config. Install it (`sudo apt install caddy` — add the official
Caddy apt repo first if it's not in your Pi OS's repos, see caddyserver.com
docs), then `/etc/caddy/Caddyfile`:

```
your-domain.example.com {
    reverse_proxy 127.0.0.1:8000
}
```

`sudo systemctl reload caddy` and Caddy will fetch and renew a Let's Encrypt
certificate automatically — *if* `your-domain.example.com` actually resolves
to your Pi's public IP (see step 5).

If you'd rather stay on the LAN only for now (e.g. just piloting with people
in the same building), skip HTTPS/domain entirely and just open
`http://<pi-lan-ip>:8000` directly, or point Caddy at plain HTTP on port 80
with `reverse_proxy 127.0.0.1:8000` and no domain.

### 5. Make it reachable from outside your home network

Pick one:

- **Port forwarding + dynamic DNS** — forward external ports 80/443 on your
  router to the Pi's LAN IP, and use a free dynamic-DNS service (e.g.
  DuckDNS) to get a stable hostname pointing at your home IP, since most
  residential connections don't have a fixed one. Requires router access and
  opening ports to your home network.
- **Cloudflare Tunnel** (recommended if you'd rather not touch router
  config or open inbound ports at all) — install `cloudflared` on the Pi,
  run `cloudflared tunnel login` and `cloudflared tunnel create nlvsmatrix`,
  then point the tunnel at `http://127.0.0.1:8000` (you can skip the Caddy
  step entirely in this case — Cloudflare terminates HTTPS for you). No open
  ports, works even behind CGNAT.

For a small internal pilot, plain LAN access (or your existing VPN back into
your home network, if you have one) is the least amount of setup.

### 6. Back up the data

The two things that matter are `instance/study.db` (all responses) and
`uploads/` (the images). Neither is in git (see `.gitignore`). A simple cron
job copying both to another disk/cloud folder periodically is enough:

```
0 * * * * cp /home/pi/nlvsmatrix/instance/study.db /home/pi/backups/study-$(date +\%F-\%H).db
```

## Notes

- Ground truth is optional per task. When it's set, `mcq`/`node_id`/`number`
  tasks are scored exactly right/wrong and `node_list` tasks get a Jaccard
  overlap score (0-1); free-text tasks are never auto-scored (per the study
  design, several tasks — e.g. neighbourhood identification on real data —
  genuinely don't have a single checkable answer) and are just recorded for
  manual/statistical review.
- `/admin/results` has an aggregated view plus CSV export of raw responses,
  workload ratings, and preferences for analysis in R/Python/Excel.
- There's no participant login — sessions are anonymous, identified only by
  a random UUID, matching the consent framing on the landing page.
